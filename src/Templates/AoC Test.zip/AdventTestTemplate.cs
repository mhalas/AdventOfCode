﻿using AdventOfCode.Shared.Contracts;
using AdventOfCode.Tasks.Year2020;
using NSubstitute;
using NUnit.Framework;
using System.Collections.Generic;

namespace $rootnamespace$
{
    [TestFixture]
    public class $itemname$
    {
        [Test]
        public void $itemname$_Part1()
        {
            IEnumerable<string> inputs = new List<string>()
            {

            };
            var readListFromFile = Substitute.For<IReadListFromFile>();
            readListFromFile.ReadFile("").Returns(inputs);

            var task = new DayXX_$itemname$(readListFromFile);

            var result = task.Execute(new List<string> { "" }).Result;
            Assert.AreEqual("", result);
        }

        [Test]
        public void $itemname$_Part2()
        {
            IEnumerable<string> inputs = new List<string>()
            {

            };
            var readListFromFile = Substitute.For<IReadListFromFile>();
            readListFromFile.ReadFile("").Returns(inputs);

            var task = new DayXX_$itemname$(readListFromFile);

            var result = task.Execute(new List<string> { "", "true" }).Result;
            Assert.AreEqual("", result);
        }
    }
}